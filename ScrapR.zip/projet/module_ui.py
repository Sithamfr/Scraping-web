#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Dec  4 09:00:27 2019

@author: cordier
"""

import tkinter as tk
import tkinter.ttk as ttk

from PIL import Image, ImageTk
import webbrowser as wb

import module_urls as mU
import module_tooltip as ttp # info-bulles



def reset(root):
    root.destroy()
    test = UI()
    test.user_interface()
    
def print_urls(frame,dictionary):
    keys = list(dictionary.keys())
    val = list(dictionary.values())
    N = len(dictionary)
    n_res = tk.Label(frame,text=f"{N} résults",fg="white",bg="#7b8a9b",anchor="w")
    n_res.pack(fill=tk.X,ipadx=10)
    tk.Label(frame,text="",bg="#7b8a9b")
    for i in range(min(25,N)):
        txt = keys[i]
        b = tk.Button(frame,text=txt,width=200,bd=1,bg="#2c3846",fg="white",
                      command=(lambda i=i: wb.open(keys[i])))
        b.pack(padx=10)
        b_ttp = ttp.CreateToolTip(b, val[i])
        


class UI:
    
    def __init__(self):
        self.fs = False # Parmaètre graphique `fullscreen`
        self.n_turn = 4
        self.urls = mU.URLS("") # Arguments pour scraper
        
    def set_screen(self,root):
        if self.fs == False:
            root.attributes('-fullscreen', 1)
            self.fs = True
        else:
            root.attributes('-fullscreen', 0)
            self.fs = False
            
    def extract_best_list(self,liste):
        d = dict(map(lambda key: (key, self.urls.counter.get(key, None)), liste))
        d = {k: v for k, v in sorted(d.items(), key=lambda item: item[1], reverse=True)}
        return d
            
    def send_saisie(self,url_start,N,ftype,frame_btn,frame_res,btn,frame_bar):
        btn.config(state="disabled")
        self.urls = mU.URLS("")
        for links in frame_res.winfo_children():
            links.pack_forget()
        frame_res.pack_forget()
        frame_res.pack()
        try :
            self.n_turn = int(N)
            self.urls.next = [url_start]
            self.urls.counter[url_start] = 1
            p = ttk.Progressbar(frame_bar,style="green.Horizontal.TProgressbar",orient ="horizontal",length = 100, mode ="determinate",
                                maximum=self.n_turn)#bg="#7b8a9b")
            p.pack()
            for n_collect in range(self.n_turn):
                self.urls.collect() # COLLECTE
                self.urls.reduce()  # REDUCTION
                p.step()   
                frame_bar.update()
            self.print_urls_type(frame_res,ftype)
        except Exception as e:
            alert = tk.Label(frame_btn,text = 'input1 should be a URL\ninput2 should be a number',bg='#2c3846',fg="red",justify=tk.LEFT)
            alert.pack()
            print(e)
            def suppr():
                alert.destroy()
            alert.after(2000,suppr)
        finally :
            btn.config(state="normal")
            for bar in frame_bar.winfo_children():
                bar.pack_forget()
            
            
    def print_urls_type(self,frame,ftype):
        if ftype=="Pages":
            print_urls(frame,self.extract_best_list(self.urls.treated))
        elif ftype=="Audio-visual":
            print_urls(frame,self.extract_best_list(self.urls.img))
        elif ftype=="Documents":
            print_urls(frame,self.extract_best_list(self.urls.doc))
                
    def change_urls_type(self,frame,ftype):
        for btn in frame.winfo_children():
            btn.pack_forget()
        frame.pack_forget()
        frame.pack()
        frame = tk.LabelFrame(frame,bg="#7b8a9b",borderwidth=0)
        frame.pack(side=tk.BOTTOM,pady=2)
        self.print_urls_type(frame,ftype)
        
            
    
    def user_interface(self):
            
        root = tk.Tk()
        root.title("ScrapR")
        root.configure(background="#7b8a9b")
        root.geometry("800x500")
        root.iconbitmap("@Images/logo_app.xbm")
        gauche = tk.LabelFrame(root,bg='#2c3846',borderwidth=0)
        droite = tk.LabelFrame(root,bg="#7b8a9b",borderwidth=0)
        gauche.pack(side=tk.LEFT,padx=30)
        droite.pack(side=tk.RIGHT,padx=30,pady=30)
        root.configure(cursor="left_ptr #a72215")
        style = ttk.Style()
        style.configure("green.Horizontal.TProgressbar", foreground='green', background='green', thickness=8)

        # BARRE DE TACHES
        menubar = tk.Menu(root, bg='#2c3846', fg='#e8f2fe', activebackground='#e8f2fe', activeforeground='#2c3846',bd=0)
        menu1 = tk.Menu(menubar, tearoff=0, bg='#47586b', fg='#e8f2fe',
                     activebackground='#e8f2fe', activeforeground='#47586b',bd=0)
        menu1.add_separator()
        menu1.add_command(label="  Full screen  ", command = lambda : self.set_screen(root))
        menu1.add_separator()
        menu1.add_command(label="  Reset interface  ", command = lambda : reset(root))
        menu1.add_command(label="  Exit interface  ", command = root.destroy)
        menu1.add_separator()
        menubar.add_cascade(label="    Tools    ", menu=menu1)
        root.config(menu=menubar)
        
        # GAUCHE
        image1 = Image.open("Images/logor.png") 
        image1 = image1.resize((210, 120), Image.ANTIALIAS)
        photo1 = ImageTk.PhotoImage(image1) 
        label1 = tk.Label(gauche,image=photo1,bd=0,bg='#2c3846')
        label1.place(x=0, y=0)
        label1.image = photo1 
        label1.pack(pady=5,padx=5)
        tk.Label(gauche,text = '  ScrapR  ',font=('Calibri',14),bg='#2c3846',fg='#82b9d7').pack(side=tk.TOP)
        tk.Label(gauche,text = '',bg='#2c3846').pack()
        tk.Label(gauche,text = '',bg='#2c3846').pack()
        tk.Label(gauche,text = '     STARTING URL :     ',fg='#f5a891',bg='#2c3846',borderwidth=0).pack()
        v1 = tk.StringVar()
        v1.set("http://")
        saisie = tk.Entry(gauche, width=25, bd=0, justify=tk.CENTER, relief=tk.FLAT, font=('Calibri',10),
                          bg='#2c3846', fg="white", highlightbackground='#da907a', textvar=v1,
                          highlightcolor="white", cursor="xterm #a72215", insertbackground="#a72215")
        saisie.pack(padx=20,pady=2)
        N_var = tk.IntVar()
        N_input = tk.Entry(gauche,textvariable=N_var,width=4,justify=tk.CENTER, relief=tk.FLAT, font=('Calibri',10), bg='#2c3846', fg="white",
                      highlightbackground='#da907a', highlightcolor="white",
                      cursor="xterm #a72215", insertbackground="#a72215", )
        N_input.pack()
        N_var.set(4)
        
        # LANCE LE PROGRAMME
        image = Image.open("Images/logo_button.png") 
        image = image.resize((40,15), Image.ANTIALIAS)
        photo = ImageTk.PhotoImage(image) 
        go_btn = tk.Button(gauche,text="Go",image=photo,bd=0,bg="white",
                           command=(lambda : self.send_saisie(saisie.get(),
                                                             N_input.get(),
                                                             v2.get(),
                                                             gauche,
                                                             basdroit,
                                                             go_btn,
                                                             frame_bar)))
        go_btn.pack(pady=10)
        tk.Label(gauche,text = '',bg='#2c3846').pack()
        tk.Label(gauche,text = '',bg='#2c3846').pack()
        frame_bar = tk.Frame(gauche,bg='#2c3846')
        frame_bar.pack()
        tk.Label(gauche,text = '',bg='#2c3846').pack()
        
        # DROITE
        tk.Label(droite,text = 'Best ScrapR results',font=('Calibri',20),bg="#7b8a9b",fg='white').pack(side=tk.TOP)
        choix = ['Pages', 'Audio-visual', 'Documents']
        v2 = tk.StringVar()
        v2.set(choix[0])
        hautdroit = tk.LabelFrame(droite,bg="#7b8a9b",borderwidth=0)
        hautdroit.pack(side=tk.TOP,anchor="e")
        w = tk.OptionMenu(hautdroit, v2, *choix,
                           command=(lambda event: self.change_urls_type(basdroit,
                                                                        v2.get())))
        w.config(width=10,bd=0,bg='#2c3846',fg="white", anchor="w")
        w["menu"].config(bd=0,bg='#47586b',fg="white")
        w.pack(side=tk.RIGHT, padx=20)
        basdroit = tk.LabelFrame(droite,bg="#7b8a9b",borderwidth=0)
        basdroit.pack(side=tk.BOTTOM,pady=2)
        
        root.mainloop()
        return
