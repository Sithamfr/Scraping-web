#!/usr/bin/env python3
# -*- coding: utf-8 -*-

""" LIBRARIES ----------------------------------------------------------------------------------"""
import asyncio, aiohttp, async_timeout, re
""" --------------------------------------------------------------------------------------------"""



""" PROGRAMS -----------------------------------------------------------------------------------"""
class URLS():
    
    def __init__(self,start):
        self.next = start
        self.treated = []
        self.img = []
        self.doc = []
        self.out = []
        self.filtered = []
        self.counter = {} # Compteur : pages, images, docs
        

    async def extract(self,url):
        try :
            async with async_timeout.timeout(8):
                async with aiohttp.ClientSession() as session:
                    async with session.get(url) as response:
                        enc = response.charset
                        if enc==None : enc='UTF-8'
                        ressource = await response.read()
                        texte = ressource.decode(encoding=enc)
                        url_tmp = motif_extract_urls.findall(texte)
                        url_tmp = del_slash(url_tmp)
                        url_tmp = self.filtering(url_tmp)
                        self.treated.append(url)
                        self.next += url_tmp
        except Exception as e:
            self.out.append(url)
            
            
            
    def extract_all(self,urls):
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop = asyncio.get_event_loop()
        loop.run_until_complete(
            asyncio.gather(
                *(self.extract(url) for url in urls)
            )
        )
        loop.stop()
        loop.close()
        
    def reduce(self):
        """
        links = self.next
        K = 0
        for lk in links:
            if lk[-1]=='/':
                links[K] = lk[:-1]
            K+=1
        self.next = links
        print(links)
        """
        self.next = list(set(self.next)) # supprime les occurences
        for url in self.next: # supprime les urls deja vus dans les urls à regarder
            if url in self.treated:
                self.next.remove(url)
        
    def collect(self):
        start = self.next
        self.next = []
        self.extract_all(start)

    def add_and_count(self,url):
        if url in self.counter.keys():
            self.counter[url] += 1
        else :
            self.counter[url] = 1
        
        
    """ FILTRE """
    def filtering(self,list_url):
        L = []
        for url in list_url :
            if self.f_domain(url):
                self.add_and_count(url) # ajout au dictionnaire des compteurs
                if self.f_format(url):
                    L.append(url)
        return L
    

    
    # FILTRE DE DOMAINE
    def f_domain(self,url):
        for domaine in url.split("/")[2].split(".") :
            for f in F:
                if f == domaine:
                    self.filtered.append(url)
                    return False
        return True
        
    # FILTRE DE FICHIERS
    def f_format(self,url):
        S = url.split(".")
        # IMAGES
        for f in ['jpg','png','ico','svg','gif','bmp','jpeg','mp3','mp4','avi']:
            for s in S[1:]:
                if f == s[:len(f)]:
                    self.img.append(url)
                    return False
        # DOCUMENTS
        for f in ["pdf","zip","doc","docx","xlsx","csv","txt"]:
            if f == S[-1][:len(f)]:
                self.doc.append(url)
                return False
        # INEXPLOITABLES
        for extrait in S[1:]:
            for f in ["js","css"]:
                if f == extrait[:len(f)]:
                    self.filtered.append(url)
                    return False
        return True
        
        
""" --------------------------------------------------------------------------------------------"""
       



""" PARAMETERS ---------------------------------------------------------------------------------"""
motif_extract_urls = re.compile(r"https?://[^\'\"\s<]+")

F = ["facebook",
     "instagram",
     "linkedin",
     "twitter",
     "youtube",
     "dailymotion",
     "google",
     "fonts",
     "googleapis",
     "apple",
     "vimeo",
     "pinterest",
     "jquery",
     "api",
     "yoast",
     "schema",
     "wordpress",
     "wp-rocket",
     "pingdom",
     "woocommerce",
     "creativecommons",
     "wpmudev",
     "w3",
     "xmlns",
     "hypermail-project",
     "intranet",
     "gmpg",
     "rdfs",
     "ogp",
     "t",
     "purl",
     "mozilla",
     "login",
     "sketchfab",
     "zendesk",
     "dnnsoftware",
     "medium",
     "cstheory",
     "securelandcommunications",
     "iana"]
""" --------------------------------------------------------------------------------------------"""


def del_slash(url_list):
    for i in range(len(url_list)):
        if url_list[i][-1]=='/':
            url_list[i] = url_list[i][:-1]
    return url_list

