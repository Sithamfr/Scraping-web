#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Nov 28 13:36:37 2019

@author: cordier
"""



import module_ui as ui
import os
import sys

if __name__ == '__main__':
    
    # SET WORKING DIRECTORY TO SOURCE FILE LOCATION
    abspath = os.path.abspath(__file__)
    dname = os.path.dirname(abspath)
    os.chdir(dname)
    
    # PRINT ERRORS IN ERRORS.LOG
    fsock = open('errors.log', 'w')  
    sys.stderr = fsock

    # LAUNCH APP
    soft = ui.UI()
    soft.user_interface()











